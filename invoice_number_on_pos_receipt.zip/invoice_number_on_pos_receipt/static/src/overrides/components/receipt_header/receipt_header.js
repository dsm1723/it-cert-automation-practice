/* @odoo-module */

import { useState } from "@odoo/owl";
import { OrderReceipt  } from "@point_of_sale/app/screens/receipt_screen/receipt/order_receipt";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { PosOrderline } from "@point_of_sale/app/models/pos_order_line";
import { useService } from "@web/core/utils/hooks";
import { patch } from "@web/core/utils/patch";
import { Orderline } from "@point_of_sale/app/generic_components/orderline/orderline";
patch(Orderline, {
    props: {
        ...Orderline.props,
        line: {
            ...Orderline.props.line,
            shape: {
                ...Orderline.props.line.shape,
                productID: { type: Number, optional: true },
                barcode: { type: String, optional: true },
            },
        },
    },
});

patch(PosOrderline.prototype, {
    setup(vals) {
        super.setup(...arguments);
    },
    getDisplayData() {
        let override = super.getDisplayData()
        override.barcode = ''
        if(this.product_id && this.product_id.barcode && this.product_id.barcode.length !=0){
            override.barcode = this.product_id.barcode;
        }
        return override
    },
});



