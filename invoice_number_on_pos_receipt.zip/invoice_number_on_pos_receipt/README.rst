Invoice Number On Pos Receipt v17E
=======================

Configuration
=============
* No additional configuration.
Company
-------
* `Aktiv Software <"https://www.aktivsoftware.com>`__

Contacts
--------
* Mail Contact : odoo@aktivsoftware.com
* Website : https://www.aktivsoftware.com

Bug Tracker
-----------
Please feel free to reach out to us using the provided contact details for any issues or concerns related to this module.

Maintainer
==========
.. image:: https://www.aktivsoftware.com/wp-content/uploads/2022/08/aktiv_new_logo_v2.png
   :target: https://www.aktivsoftware.com

This module is maintained by Aktiv Software.
