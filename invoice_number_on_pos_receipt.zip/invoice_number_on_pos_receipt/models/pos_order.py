# -*- coding: utf-8 -*-
# Part of Odoo, EL and Aktiv Software.
# See LICENSE file for full copyright & licensing details.

from odoo import models


class PosOrder(models.Model):
    """Inherited: Pos Order"""
    _inherit = 'pos.order'

    def generate_invoice_number(self, data):
        """
            Generate the invoice number for a given POS order.

            This method retrieves the invoice number for a POS order identified by the provided `data`.
            It uses the `pos.order` model to browse the specific order and fetch its associated account move name,
            which is used as the invoice number. If the order or account move is not found, an empty string is returned.

            Returns:
                str: The invoice number associated with the POS order. Returns an empty string if the invoice number
                      cannot be found.

            """
        return self.env["pos.order"].sudo().browse(int(data)).account_move.name or ''
