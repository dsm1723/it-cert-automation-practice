# -*- coding: utf-8 -*-
# Part of Odoo, EL and Aktiv Software.
# See LICENSE file for full copyright & licensing details.

from . import pos_order
