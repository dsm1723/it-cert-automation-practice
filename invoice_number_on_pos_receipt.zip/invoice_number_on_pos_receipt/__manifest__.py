# -*- coding: utf-8 -*-
# Part of Odoo, EL and Aktiv Software.
# See LICENSE file for full copyright & licensing details.

{
    'name': 'generate_invoice_number_on_pos_receipt',
    'summary': 'Generate Invoice Number in Pos invoice receipt ',
    'author': 'Aktiv Software',
    'website': 'http://www.aktivsoftware.com',
    'version': '18.0.0.0.0',
    'category': 'Sales/Point of Sale',
    'depends': ['point_of_sale'],
    'assets': {
        'point_of_sale._assets_pos': [
            'invoice_number_on_pos_receipt/static/src/**/*',
        ],
    },
    'application': False,
    'license': 'OPL-1',
}
